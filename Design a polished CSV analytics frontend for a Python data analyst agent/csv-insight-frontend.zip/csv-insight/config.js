// Set to your Python API origin to enable backend upload, progress polling, Plotly dashboards, and live Q&A.
// Example: window.PIVOT_API_BASE = "http://localhost:8000";
window.PIVOT_API_BASE = window.PIVOT_API_BASE || "";
