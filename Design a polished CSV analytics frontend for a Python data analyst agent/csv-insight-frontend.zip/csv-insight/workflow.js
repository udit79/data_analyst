(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const apiBase = () => String(window.PIVOT_API_BASE || '').replace(/\/$/, '');
  let activeAnalysisId = null;
  let demoSendMessage = window.sendMessage;
  const stages = [
    { key: 'uploading', label: 'Receiving your CSV', note: 'Sending the file securely to your analyst.' },
    { key: 'profiling', label: 'Profiling your data', note: 'Checking columns, types, and data quality.' },
    { key: 'charts', label: 'Building your Plotly dashboard', note: 'Preparing charts and useful comparisons.' },
    { key: 'insights', label: 'Finding the story', note: 'Pulling together the patterns worth noticing.' },
    { key: 'complete', label: 'Your dashboard is ready', note: 'Explore the charts or ask a follow-up question.' }
  ];
  const progress = $('#analysis-progress');
  let currentFileName = '';
  function showProgress() {
    progress.hidden = false;
    progress.classList.remove('progress-error');
    progress.innerHTML = `<div class="progress-heading"><div><div class="panel-kicker">LIVE ANALYSIS</div><h3>Turning your CSV into a dashboard</h3><p id="progress-file"></p></div><span class="progress-percent" id="progress-percent">0%</span></div><div class="progress-track" role="progressbar" aria-label="Analysis progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span id="progress-fill"></span></div><div class="progress-steps" id="progress-steps"></div><div class="progress-note" id="progress-note"></div>`;
    $('#progress-file').textContent = currentFileName;
    $('#progress-steps').innerHTML = stages.slice(0, 4).map((s, i) => `<div class="progress-step" data-step="${s.key}"><span class="step-marker">${String(i + 1).padStart(2, '0')}</span><span>${s.label}</span></div>`).join('');
    progress.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  function setProgress(percent, message, status = 'running') {
    const value = Math.max(0, Math.min(100, Number(percent) || 0));
    const fill = $('#progress-fill');
    if (!fill) return;
    $('#progress-percent').textContent = `${Math.round(value)}%`;
    fill.style.width = `${value}%`;
    $('.progress-track', progress).setAttribute('aria-valuenow', String(Math.round(value)));
    $('#progress-note').textContent = message || '';
    const stepIndex = status === 'completed' ? 4 : value < 18 ? 0 : value < 42 ? 1 : value < 75 ? 2 : 3;
    $$('.progress-step', progress).forEach((step, i) => {
      step.classList.toggle('done', i < stepIndex || status === 'completed');
      step.classList.toggle('current', i === stepIndex && status !== 'completed' && status !== 'failed');
      step.classList.toggle('failed', status === 'failed' && i === stepIndex);
    });
    if (status === 'completed') {
      $('#progress-note').textContent = message || stages[4].note;
      $('#progress-percent').textContent = '100%';
      fill.style.width = '100%';
    }
    if (status === 'failed') progress.classList.add('progress-error');
  }
  function updateMeta(file, result = {}) {
    $('#dataset-name').textContent = file.name.replace(/\.csv$/i, '').replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    $('.dataset-meta span:nth-child(2)').textContent = file.name;
    const count = result.row_count ?? result.rows ?? null;
    if (count != null) $('#row-count').textContent = `${Number(count).toLocaleString()} rows`;
    else {
      const countText = $('#row-count').textContent;
      if (!countText || countText === '2,481 rows') $('#row-count').textContent = 'Analyzed rows';
    }
    const badge = $('.status-pill');
    if (badge) badge.innerHTML = '<i></i> ANALYZED';
  }
  function activatePlotlyDashboard(result = {}) {
    const panel = $('#plotly-dashboard-panel');
    const frame = $('#plotly-frame');
    const html = result.plotly_html || result.dashboard_html;
    const url = result.dashboard_url || result.plotly_url;
    if (html) {
      frame.removeAttribute('src');
      frame.srcdoc = html;
      frame.setAttribute('sandbox', 'allow-scripts');
      panel.hidden = false;
      $$('.metrics-grid, .dashboard-grid, .bottom-grid').forEach(el => el.hidden = true);
      return true;
    }
    if (url) {
      frame.removeAttribute('srcdoc');
      frame.removeAttribute('sandbox');
      frame.src = url;
      panel.hidden = false;
      $$('.metrics-grid, .dashboard-grid, .bottom-grid').forEach(el => el.hidden = true);
      return true;
    }
    panel.hidden = true;
    return false;
  }
  async function readResponse(response) {
    let payload = {};
    try { payload = await response.json(); } catch (_) {}
    if (!response.ok) throw new Error(payload.message || payload.detail || `Request failed (${response.status}).`);
    return payload;
  }
  async function runBackend(file, rows) {
    const base = apiBase();
    const form = new FormData();
    form.append('file', file, file.name);
    setProgress(8, 'Uploading your CSV to the analysis service.');
    const created = await readResponse(await fetch(`${base}/api/analyses`, { method: 'POST', body: form }));
    const id = created.analysis_id ?? created.id;
    if (!id) throw new Error('The analysis service did not return an analysis_id.');
    activeAnalysisId = id;
    let state = created;
    let started = Date.now();
    while (!['completed', 'complete', 'succeeded', 'failed', 'error'].includes(String(state.status || '').toLowerCase())) {
      const pct = state.progress ?? Math.min(93, Math.max(12, Math.round((Date.now() - started) / 500)));
      setProgress(pct, state.message || 'Your analyst is working through the next step.');
      await new Promise(resolve => setTimeout(resolve, 1100));
      state = await readResponse(await fetch(`${base}/api/analyses/${encodeURIComponent(id)}`));
    }
    if (['failed', 'error'].includes(String(state.status).toLowerCase())) throw new Error(state.message || 'The analysis could not be completed.');
    const result = state.result || state;
    renderCSV(rows, file.name);
    updateMeta(file, result);
    const embedded = activatePlotlyDashboard(result);
    setProgress(100, embedded ? 'Your Plotly dashboard is ready below. Ask a question whenever you spot something interesting.' : 'Analysis complete. The service did not include a dashboard URL or Plotly HTML in its response.', 'completed');
    if (result.metrics?.revenue != null) {
      $('#revenue-value').innerHTML = `${new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(result.metrics.revenue)}<span class="metric-decimal">.00</span>`;
      $('#chart-total').textContent = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(result.metrics.revenue);
    }
  }
  async function runDemo(file, rows) {
    setProgress(12, 'Demo mode · no analysis backend is connected. Previewing the upload locally in your browser.');
    const pauses = [[31, 'Checking the CSV structure and recognizing likely column types.'], [57, 'In a connected build, the Python service now profiles the data.'], [82, 'In a connected build, Plotly charts and AI insights are prepared here.']];
    for (const [pct, message] of pauses) {
      await new Promise(resolve => setTimeout(resolve, 550));
      setProgress(pct, message);
    }
    renderCSV(rows, file.name);
    updateMeta(file, { row_count: rows.length - 1 });
    activatePlotlyDashboard({});
    setProgress(100, 'Local preview ready. Connect the Python analysis API to replace this demo with its Plotly dashboard and live progress.', 'completed');
  }
  window.loadFile = async function(file) {
    if (!/\.csv$/i.test(file.name) && file.type !== 'text/csv') { toast('Please choose a .csv file.'); return; }
    if (file.size > 25 * 1024 * 1024) { toast('That file is over the 25 MB upload limit.'); return; }
    currentFileName = file.name;
    activeAnalysisId = null;
    $('#plotly-dashboard-panel').hidden = true;
    $$('.metrics-grid, .dashboard-grid, .bottom-grid').forEach(el => el.hidden = false);
    showProgress();
    try {
      const text = await file.text();
      const rows = parseCSV(text);
      if (rows.length < 2) throw new Error('Your file needs a header and at least one data row.');
      if (apiBase()) await runBackend(file, rows);
      else await runDemo(file, rows);
      toast(apiBase() ? 'Your Plotly dashboard is ready.' : 'CSV preview ready · demo mode');
    } catch (error) {
      setProgress(0, error.message || 'Something went wrong while analyzing this file.', 'failed');
      $('#progress-note').textContent += ' Check that the API is available, then try again.';
      toast(error.message || 'Could not analyze that CSV.');
    }
  };

  window.sendMessage = async function(text) {
    if (!apiBase() || !activeAnalysisId) return demoSendMessage(text);
    if (!text || !text.trim()) return;
    const body = $('#chat-body');
    const user = document.createElement('div'); user.className = 'user-message'; user.innerHTML = `<span>${escapeHtml(text)}</span>`; body.appendChild(user);
    $('#chat-input').value = '';
    const reply = document.createElement('div'); reply.className = 'reply-message reply-loading'; reply.textContent = 'Checking your data…'; body.appendChild(reply); body.scrollTop = body.scrollHeight;
    try {
      const response = await fetch(`${apiBase()}/api/analyses/${encodeURIComponent(activeAnalysisId)}/questions`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: text }) });
      const answer = await readResponse(response);
      reply.textContent = answer.answer || answer.message || 'The analyst did not return an answer.';
      reply.classList.remove('reply-loading');
    } catch (error) { reply.textContent = `I couldn't reach the analysis service: ${error.message}`; reply.classList.remove('reply-loading'); }
    body.scrollTop = body.scrollHeight;
  };

  const themeButton = $('#theme-toggle');
  const savedTheme = localStorage.getItem('pivot-theme');
  if (savedTheme === 'dark') document.body.dataset.theme = 'dark';
  function refreshThemeControl() {
    const dark = document.body.dataset.theme === 'dark';
    themeButton.innerHTML = `<span class="theme-icon">${dark ? '☼' : '◐'}</span><span>${dark ? 'Light mode' : 'Dark mode'}</span>`;
    themeButton.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
    themeButton.title = dark ? 'Switch to light mode' : 'Switch to dark mode';
  }
  refreshThemeControl();
  themeButton.addEventListener('click', () => {
    document.body.dataset.theme = document.body.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('pivot-theme', document.body.dataset.theme);
    refreshThemeControl();
  });
})();
